# Resume 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Kavahnti31-the-solid/pen/ExzXWmr](https://codepen.io/Kavahnti31-the-solid/pen/ExzXWmr).

